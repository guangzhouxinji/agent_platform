# ADR-AGENT-BINDING-02：持久化与三域增量接线的限定技术设计

日期：2026-10-05。来源：本轮附件指令（用户授权技术重构、并行增量推进，不替代正式权限/法律批准）、docs/01/09/54、既有三域正式API/服务。状态唯一见docs/08。任务：ARC-AGENT-VERTICAL-02，IMP-AGENT-RUNTIME-KERNEL-01，IMP-AGENT-MODEL-GATEWAY-01及三域接入任务。

## 1. 最小依赖与R/D范围

Phase是推荐顺序，不再以Runtime全部尾项或另一业务Agent完成作为前置。三域只依赖内核已交付机械协议和自己的既有能力；不能复用其他Agent内部实现。当前R是用户批准的技术接线及各域已获准的业务能力合同；当前D只覆盖下述持久化、共享模型传输和受控既有能力编排，不代签新增法律规则/材料用途/专业验收。

## 2. 生产Checkpoint数据服务端口

V096/U096：共享run head和不可变revision。Head精确绑定agentId/taskId/goalId/goalVersion/scope和父输入截止时间；版本CAS；revision保存加密checkpoint+audit事件并计算SHA。AES-256-GCM，随机nonce和绑定run/agent/task/version的AAD，密钥只从正式配置获得；不给默认密钥。JSON大小有限，不存JWT、API密钥、权限快照或第三方原始材料正文。Goal只保存业务输入引用和机器完成合同，输入/源仍由原领域保管。

生产适配器通过CurrentAccess回调在读、事务开始和提交前核查现时Task/Goal/Input/权限/保留；通过ExecutionFence回调核查调用方当前围栏。不会建立通用身份或自行签发权限。工具的业务写入继续使用原命令幂等和领域围栏；Checkpoint并发CAS不替代业务命令围栏，也不宣称跨系统exactly-once。故障原件保留，load校验SHA/密文/AAD/绑定；恢复不能跨Agent/Task借用。保留期限由当前父任务/输入/来源已批准截止取最早，不自创无限保留；适配器过期拒绝读取并支持按现有截止清除。

## 3. 共享模型入口

共享ModelGateway端口位于kernel，供应商HTTP在model adapter内；域持有Prompt/用途/输出校验。共享传输接收显式provider/model/endpoint/protocol/timeout/输入输出预算/批准版本和目的；不自行放大审批、切换模型或重试不确定外呼。保持原exactRequest字节、finish_reason、模型一致性、usage、输出上限和中断语义。咨询受管配置优先复用；裁决从已批准MaterialModelPolicy取得精确模型，通过显式配置endpoint与批准绑定接入，不再由材料adapter写死模型名和URL。其他供应商/目的/模型仍需原批准，不把可配置当已批准。

## 4. 三域独立Agent

各模块独立Definition/Skills/Tools/Policy/Prompt/Evaluation版本和独立Runtime实例，不在kernel放业务流程。增量先复用当前真实检索/证据程序/材料报告服务；三个Agent仅调用自己领域端口。工具只提交候选/草稿或调用已有确定性规则，不调用授权写入、review/publish/正式处罚或裁决状态端口。机器完成依领域证据和缺口；须人工时NEED_HUMAN，不因为模型声明完成而SATISFIED。

可恢复工具错误进入Evaluate/Re-plan，错误引用保存机械分类，不记录密钥/异常正文。权限失效停止且不恢复旧授权，预算不足停止；未知提交状态必须用原幂等回执对账，不盲目重发模型请求。各域后续细化仍在同一主计划追踪，不用当前窄切片冒全部业务完成。

## 5. 验证与安全

H2测试适配器真SQL/事务/CAS/并发/加密/回滚/重启；真实DM8使用新隔离测试库或随机自有schema，不运行迁移到原业务库。已有缺实证前置的20错误需恢复原对账环境，随机空库不能冒替；不因此冻结新实现。共享模型测试使用受控本地HTTP/TLS供应商，明确不等于供应商/专业效果验收。三域接线逐条运行实际服务与持久化并保存恢复/权限/重规划/失败原件，未穿透的范围不标DONE。


## 共享工作台限定增量技术 D（2026-10-05）

本切片仅消费已实现的三个领域 `agent-runs` 合同，不新增身份、正式决定或跨领域调用。共享 React 组件接收领域授权请求端口，展示服务端 Goal/Phase/Plan/Cursor/Pending/Observation/Event/Outcome，不预设成功进度。裁决从当前案件版本显式启动不使用模型的材料组织/候选/缺口/辅助报告链；模型选择仍由现有批准材料合同控制，不自动发送材料。咨询必须已有确切 confirmed Goal；执法启动必须已有完整原生 Input 与程序检查合同，缺合同不在前端猜测规则。其他分支可以先用确切 Run ID 读取和继续已授权运行。

执行步骤为显式单次推进，不以静态动画/自动成功替代后台运行。失权清除正文；网络不确定保留同一创建键且禁止未经对账换键提交；推进网络不确定先读取 Run。切换任务/身份丢弃旧响应。停止后的继续按钮禁用，人工复核沿各领域原生业务入口，不在 Runtime 中伪造审批。历史列表/全文证据解析/自动执行与完整三域 E2E 为后续退出条件，不在此设计切片声明实现。


## 当前装配与部署前置

三个独立产品入口均显式导入共享 `AgentRuntimeConfiguration`/`AgentRunPersistence`，不要求扫描其他业务Agent。默认 `AGENT_RUNTIME_ENABLED=false`；启用必须显式配置32字节Base64 `AGENT_RUNTIME_CHECKPOINT_KEY`，不得用测试密钥/历史默认身份。需要先通过现有受控迁移入口应用V096（U096为回滚原件），本轮未向现存业务schema运行迁移。独立数据库权限应限定于两个Runtime表及各领域已有授权端口；密钥保管/备份/轮换沿部署系统，不写入报告或Checkpoint。

咨询额外要求既有identity、source engine、model、workspace四项开关和真实mTLS Worker/维护配置；缺任一项不能装配产品Agent Controller。裁决额外要求`adjudication.v2.enabled`及原CaseSourceAuthority/Grant水位；执法额外要求`enforcement.v2.enabled`及原材料/规则/模板/程序配置。三域端点均处于原JWT安全匹配路径内；各Controller/Tool/SQL事务重核当前权限。Runtime开关不授予任何领域权限。

共享HTTP Gateway已经接入回答、检索对话、材料整理、专利候选分析/特征提取和意图提取；健康探针与完整受管路由/成本汇总/可用性审计仍需独立核查。保留历史HTTP状态可追溯的结构化Failure，不泄露供应商响应或凭证。裁决供应商和模型批准限制不放宽。

复验入口：`scripts/verify-agent-runtime.ps1`。`-Dm8`仅使用明确注入的两个独立DM8实例，Checkpoint与CaseApi测试创建/清除随机自有schema。脚本保留前后verify-all红灯及全量历史错误，专项通过不能覆盖全量失败。原始XML、日志和结果留存；不冒法律正确性、真实案件效果或真人采用。


## 固定时钟回归限定技术D（2026-10-05）

恢复环境的全量真实暴露既有H2工程夹具混用固定Clock和系统Instant：Comparison准备/输入测试固定2026-10-05T12:00Z，但共用admit用壁钟填写collected_at，21:00北京时间后越过其固定valid_until。数据约束正确，不改数据库/生产授权或许可。仅新增测试工具显式Clock重载，让固定Clock夹具的Task/Grant/Source共用同一时间；其他调用保留原壁钟语义。旧冻结业务/专业规则不重开，旧失败、源SHA和测试源原件保存。新回归任务仅证明42个既有测试不依赖当前日期；不冒来源用途或真人验收。
