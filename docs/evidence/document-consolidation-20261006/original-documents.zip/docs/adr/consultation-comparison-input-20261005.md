# 专业对照 ComparisonInput 限定物理设计

日期：2026-10-05；IMP-CON-PRODUCT-COMPARE-01 / PC-COMPARISON-INPUT-01。依据已通过原对照D §2/5/6和prepare/特征确认限定D，不重开Task/Source/身份D。只实施正式创建、读取、不可变输入和候选执行槽，不借现有检索Worker授权发布对照。

请求为expectedTaskVersion、featureRevisionId/featureRevisionNumber/packageSha、previousComparisonId、methodVersion及Idempotency-Key。只接受PATENT_FEATURE_MATRIX_V1；不接受客户端矩阵、授权状态或隐含模型输入许可。Task COMPARE和READ均须通过ProductConsultationAccess；已确认FeatureRevision须仍为本Task current，包SHA/父版本/行/审计闭合。新请求锁Task，前comparison指针CAS；同键同载荷且仍具当前权限重放同回执，异载荷409。

公开创建/读取回执仅返回comparisonId/inputSha、Task版、FeatureRevision/包SHA、purpose/method、截止和实际逐候选进度；内部现时授权快照/Grant主体与ID不外露。进度是持久执行槽的真实状态，不以QUEUED称已分析。完整矩阵/报告由后续结果端口消费，不在创建回执中伪造。

从FeatureRevision的preparation重读目标和候选，创建时要求当前Goal/Input/Task版本；确认原文与materialSha相同，允许现时授权代数推进，但不得替换文献、原件、权项分支或确认特征。新输入固定本次完整权限与material快照、FeatureRevision/packageSha/原准备关系、purpose和methodVersion。期限为Task/Feature/preparation/当前材料各自期限最小值，保留沿本Task既有ref/version/evidenceSHA。无SAVE仍仅保存引用/定位/哈希/权项关系与用户确认说明，不保存第三方全文。

V095/U095仅新增con5_comparison_input、con5_comparison_candidate、con5_comparison_current、con5_comparison_event。input关联同Task的FeatureRevision及preparation；唯一Task/主体/request；候选槽绑定同preparation的原准备候选(document_role='CANDIDATE')，初态QUEUED不代表Worker执行或分析。current指针及创建事件与input/全部候选同事务；最后权限/Task/Feature/材料复核失败全回滚。native候选投影与canonical包交叉校验，缺行/篡改/父错绑拒绝。消费前再次验证current指针/Feature/Goal/Input/权限；历史读取只核当前读取权与相同材料，不复活旧权限。U095在有input历史时第一步拒绝，不删除历史回退；空表才允许逆迁移。

正向：同Task确认版创建→确切候选槽→同回执重放→授权读取。反向：旧特征/旧Task/旧comparison指针、不同请求载荷、越权、材料/包漂移、过期、缺事件表/末尾失权全回滚、候选丢行、非空逆迁移拒绝。以上已反演闭合，释放本限定物理实现D；不宣称真实DM8 I、模型/Worker执行、完整矩阵或专业B已通过。Worker后续必须独立核正式服务证书、双主体COMPARE Grant、精确委托、COMPARISON源范围及围栏，不能把本输入或QUERY历史当权限。
