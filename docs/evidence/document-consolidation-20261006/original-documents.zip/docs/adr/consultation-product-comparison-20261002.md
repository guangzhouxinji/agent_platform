# 首条咨询专业技术对照产品设计

版本：D1（2026-10-04补§10用途适配）；日期：2026-10-02；任务：ARC-CON-PRODUCT-COMPARE-D-01。

## 1. 依据与限定

原需求为只读 `requirements/知识产权咨询助手/专利相似度判断需求文档.md` §1～9（PC-01～09），R证据REQ-CON-R-CORE-12；沿用docs/56 CON-06及docs/69 §3，不重新设计五项协议。项目负责人已授权开发团队确定最终产品专业技术方法及工程基线；Codex负责本技术决定，不代签第三方数据权利、专业金标或业务验收。

此D定义最终文本对照产品，不把来源准入当方法设计前置。对应实现仍依赖主计划IMP-CON-PRODUCT-SOURCE-01；真实CLAIMS原文、逐用途许可、模型能力、质量样本未具备时，相应I/B不得通过。旧TITLE×QUERY授权不隐含COMPARE、DISPLAY、SAVE或MODEL_INPUT。外观设计及数值评分保持各自能力边界，不能用文本分数或检索分数补齐。

## 2. 输入、目的与版本

- 目的为TECHNICAL_SIMILARITY、CLAIM_ALIGNMENT、NOVELTY_ASSISTANCE、DESIGN_ASSISTANCE，对应原需求四目的；只前两项具备文本矩阵方法，新颖性辅助额外要求明确相关日期/地域及该法域的依据版本，缺少时只返回资料缺口，不悄悄切换目的。没有图像/视图及独立规则时外观准备返回CAPABILITY_UNAVAILABLE，不创建文本分析。
- 输入至少有同一组织的taskId、expectedTaskVersion、goalRevision、inputRevision、目标、候选及purpose。目标为用户技术方案不可变原文版或来源中的目标专利精确documentVersion；二者都无或同时给出但关系不明时422要求澄清，不能以检索query自动生成目标。
- 候选保存sourceId/contractVersion/decisionId/sourceEpoch/documentId/documentVersion/sourceVersion/rawSha及选定权项；来自检索时另绑定selectionId/revision/memberId/resultSetId，直接指定不强迫先检索。一个申请的不同公开版本不得互换。
- FeatureRevision绑定目标原文SHA、权项闭包版、purpose、用户确认主体/时间及前一修订；每Feature有稳定featureId、原文跨度、上下文、父特征/权项来源及确认说明。自然语言修订保存用户原文，不冒原专利文本；建议仍不构成确认。候选变更不改变旧FeatureRevision，但新分析输入必须重新锁定候选版。
- comparisonId与taskId分别标识分析批次及原咨询任务；纠正/继续仍为同一Task的新输入/分析版，不重开新Task掩盖版本关系。允许用户独立新建任务，但不得覆盖旧历史。

## 3. 原文与权项展开

原文端口只返回精确文献版、字段、原始字节摘要、解析器版、定位映射、质量信息与实际可读范围。定位是原件UTF-8字节半开区间[start,end)，保存字段/权项号/段落或页锚及该跨度SHA；不在规范化文本上计算原件偏移。引用必须可重读并匹配字节，不以URL或模型复述代替定位。

权项解析保留原文和引用表达式，编号不得仅按行序猜测。对每个所选权项递归展开前项DAG；保留独立/从属层级和继承来源，多项择一引用保留分支，不把多个替代分支的特征强行合并为一个权项。缺前项、循环、歧义或跨版引用阻止该权项完整分析；准备响应列明路径及待确认，用户可按原文确认解析修订但不能确认不存在的前项。

说明书支持只是独立证据，不能自动变成权项限定。每个候选权项对照必须取得选定权项及有效依赖原文；摘要/标题不能替代。OCR只有映射/质量满足时可用；未确认质量不造置信阈值，以无法核证标记并请求校对。任何清洗/拆分保留原始字节，派生文本版本独立。

## 4. 最终方法：版本化证据矩阵

方法标识PATENT_FEATURE_MATRIX_V1。每一候选×每一确认特征有且仅有当前结果行（同一特征允许多处证据）。行绑定inputSha、FeatureRevision、candidateVersion、claimBranch、methodVersion与机器生成版本，不能用报告摘要替代。

| 关系 | 必备条件 | 禁止推论 |
| --- | --- | --- |
| 对应 | 有该候选具体原文定位、原文内容、相同点与逐项理由 | 文本对应不等于法律等同或侵权 |
| 部分对应 | 有可定位证据，同时列出实际差异/缺失子项 | 不把未分析部分当不相似 |
| 已核范围内未找到 | 保存实际分析字段/权项/段落范围、解析版、方法、完成事实与限制 | 不宣称文献绝无该内容或穷尽检索 |
| 无法判断 | 缺原文、质量、解析、含义/上下文或方法支持，明确原因 | 不计0分、不假造否定证据 |
| 未分析 | 取消、排队、模型失败或预算未完成，明确运行原因 | 不标完成、不省略结果行 |

AI只建议Feature/span/关系/理由，不写确认、Grant、复核或正式状态。领域校验器核文献/跨度/摘要、引用路径、行完整性及允许的表达；模型返回不存在的span/字段/Feature或完整范围未实际分析时拒该候选提交。严格字符串相等可以作为词面证据，不能规则推定技术语义等同。用户确认的是特征输入，不自动确认机器对应关系。

报告同时保存机器建议属性及未复核状态；允许作为明确标注限制的辅助技术参考。正式采用或法律相关意见由具名有权人工复核其确切报告版。新颖性辅助按单篇单权项分支列覆盖，不把候选A/B证据拼成一个候选；不输出侵权、新颖性、创造性、有效性、授权或驳回结论。

V1不出百分数。保留评分能力缺口及原因SCORE_NOT_CALIBRATED，数值字段不存在而不是0。后续分母/权重/部分对应/未知项规则及专家样本标定另形成同任务技术设计，不从检索score或模型logit借分；本D不宣称PC-05/08效果验收完成。

完整行合同包括relation、sameAspects、differences、reasoning、uncertainty、analyzedRange、citations和生成主体/时间/版本。未知/未分析行的空证据是缺口，不允许伪造引用；有差异但不能定位时只能无法判断。模型响应保留原件，领域校验失败保存错误而不是删掉失败原件。对未找到，analyzedRange列明已实际处理的所有字段/权项分支/span和未处理范围；分块失败不得说全字段完成。

输入/报告摘要沿用现有产品canonical JSON约定（固定版、按键排序、UTF-8、SHA-256），精确包含目标/特征/候选原件与定位、purpose/条件/方法/模型参数及所有行/实际范围/缺口。数组按稳定candidate/feature/branch/位置排序；实际记录中的ID、父版本、运行事实/回执关系另有包摘要共同校验，不能通过去掉关系字段绕过版本核验。消费者重读整包后核摘要，不从分页拼出未经核验的新报告。

## 5. API、授权与执行边界

路径前缀 `/v2/consultation/tasks/{taskId}`，全部最终产品请求链；不注册旧V0/V1或开发profile旁路。

| 相对路径/动作 | 固定输入与结果 | 授权/副作用 |
| --- | --- | --- |
| POST /patent-comparisons/prepare | 输入版、目标/候选/目的→可用性、权项树、特征建议、待补项、准备摘要 | Task READ；逐源DISPLAY/COMPARISON，模型另核MODEL_INPUT；不确认特征或签执行token |
| POST /patent-comparisons/features/confirm | expectedTaskVersion/prepareSha/前FeatureRevision/确认特征/requestId→不可变FeatureRevision | Task WRITE；原文版仍可读，确认CAS/审计同事务 |
| POST /patent-comparisons | inputRevision/FeatureRevision/候选/方法/幂等键→comparisonId/输入摘要/逐候选进度 | Task COMPARE；固定输入、范围及执行槽，不接受客户端结果/授权状态 |
| POST /executions/{attemptId}/patent-comparison-result | 正式Worker/token/精确comparisonId/candidateId→产品计算并提交的回执 | 现有Worker授权/委托/租约/围栏；请求不是任意客户端上传一张结果表 |
| GET /patent-comparisons/{id} 与 /reports/{version} | 逐候选/完整矩阵/原件引用/版本/缺项/限制 | Task READ及逐证据当前来源用途；撤权不得从历史报告泄漏原文或摘要 |
| POST /patent-comparisons/{id}/retries | 当前版/失败候选id/幂等键→新attempt | COMPARE；只重试失败/未分析对象，成功历史不抹除 |
| POST /patent-comparisons/{id}/cancel | expectedVersion/requestId→取消回执 | Task WRITE；旧围栏失效；已提交行保留 |
| POST /patent-comparisons/{id}/reviews | 精确reportVersion/reportSha/人工意见/action/requestId→审核版 | HUMAN_REVIEW及现有职责/精确资源Grant；服务主体禁止，旧版冲突409 |

上述动作复用ProductAccessPolicy枚举，Task资源动作使用TASK_WORK，来源逐字段用途使用COMPARISON/模型另核MODEL_INPUT，不把Task READ当原文DISPLAY授权。ProductConsultationAccess当前仅人类Task适配，Worker必须复用正式Worker端口，不能把服务JWT塞成人类。专用来源范围/用途授权接口需在实现中按此合同适配，通用Grant不得绕过现时来源范围核验。

启动、原件读取、模型调用前及publish/消费前均核当前主体/委托/Task/DataScope/Source/独立水位。失联或PENDING停止，历史scope绝不成为当前权限。模型端口可用能力、版本/hash、输入字段及实际预算写入attempt；模型不能直接写领域表。

## 6. 领域数据、事务与恢复

领域模块依赖ComparisonDocuments、ComparisonSuggestions、ComparisonPersistence、CurrentComparisonAuthorization端口；应用层适配现有原件、模型、DM8及Worker，领域不依赖厂商SDK。逻辑实体如下，物理表/正逆迁移需实现时复审并按仓库下一个未占号迁移创建，不能占用其他域现有V085/V086。

- ComparisonPreparation：task/input/目标及候选版、可用范围、解析版、建议输出原件SHA。
- FeatureRevision及Feature/ClaimDependency：不可变原文/确认/父修订，权项分支与定位完整关联。
- ComparisonInput：comparison/task/goal/input/FeatureRevision/候选版/用途/方法/参数/范围SHA、保留策略ref/version、expiresAt。
- CandidateAttempt/ReportRevision/ComparisonRow/Citation：父子FK，唯一(report,candidate,feature,branch)、稳定顺序、运行状态及错误、机器原件/模型版/范围/证据摘要；人工修订/Review另存actor/父机器版/前人工版/动作及SHA。
- CorrectionDependency：受影响Feature/候选/权项/行及派生报告引用边，历史不可变；幂等回执绑定主体/task/输入SHA/attempt/fence/reportSha。

确认特征事务锁Task/CAS，插不可变版、审计及回执，复用当前Task版本/跨轮规则，不能保持旧Input现时指针。创建分析事务锁Task/Input，固定完整快照及执行槽；模型推理在事务外，成功候选提交在现有execution.publish业务事务中核当前输入/fence/权限，再原子写attempt/报告/全部必要行/引用/回执并COMMITTED。缺表/引用漂移/重复成员/旧token时全部回滚，不能空回调COMMITTED。

每候选独立attempt；A已提交/B故障为PARTIAL，必要矩阵未齐不宣称全批完成。取消之后旧候选token不能发布；取消不删除已完成历史。相同幂等键相同当前scope返回同一回执，不同输入409；过期、撤权或失效后不借重放恢复访问。时间、状态及授权判断服务端产生。

保留沿用当前Task/原文/结果保留策略，显式ref/version及许可的SAVE/审计边界；不得自己加统一永久保留或以全库最早过期限制新包。原文无SAVE只能保留许可范围内的引用/摘要事实，不存被禁文本。结果/原件不可读不等于撤销历史事件。

现有主库+独立现时库+文件联合备份机制直接复用。恢复核FK及唯一约束、Task/输入/特征/权项闭包/报告/人工父版/回执/fence、原件SHA/locator、历史模型/方法、所有digest。恢复不重推模型、不篡改原机器输出，不用历史Grant/Source水位覆盖独立现时权威；恢复后正常/越界/撤回请求与旧token仍需实际验证。

## 7. 纠正与按需人工

修改F2创建FeatureRevision N+1，沿显式依赖边标F2及依赖F2的权项/行/汇总失效；F1无依赖且文献/方法/权限不变可以以carryForwardFrom引用旧行，不能拷贝并伪装重新分析。候选原件或方法版改变影响该候选全部行；目标全版改变无法证明局部关系则该目标全部相关行失效。分析继续创建新Input及围栏，旧报告不可变。

人工修改为独立修订，不写机器行。再生成机器版不得覆盖人工；新机器与旧人工同时存在但旧人工不得自动审核新报告。正式采用、复核或受理不互相蕴含权限；必要受理能力沿docs/69 §4，不在此实现D中额外确定岗位/职责分离。普通查询不强制对照，普通辅助对照不强制人工受理。

## 8. 故障、预算与验证标准

401未认证；404未知/不可访问Task或报告（不泄漏跨组织存在）；403已知自己范围但动作/用途无权；409版本/幂等/旧token/原件版冲突；422输入、权项依赖或必要材料不足；503当前水位/原件/模型基础设施不可用。候选失败保存稳定errorCode及范围，不把模型故障变零分/未找到。准备阶段可返回结构化缺口，不能悄悄创建成功分析。

预算为版本化工程配置，首版最大20候选、200确认特征、最多4000行（引用分支展开超过即422），服务端逐候选应用既有Task/lease截止及模型窗口/文件大小预算；没有无限重试或丢尾截断。超预算说明可分批输入，不能自动略掉必要特征。性能验收须真实数据测prepare/执行/读取p50/p95/p99、最大矩阵、失败率/超时/内存，未实测不称SLO通过；不借Search的300ms指标作为模型对照指标。

| 验证 | 正例及必须反例 | 证据层次 |
| --- | --- | --- |
| PC-01/09 | 直接/选择入口同对象精确版；跨Task/范围、撤回原文、停用/撤权、旧水位拒绝 | C及正式HTTP I分别留存 |
| PC-02/03 | 所选从属项含前项且保层级；循环/缺前项/择一错误合并/假偏移/越界UTF-8/错误SHA拒绝 | 机械原文C不冒真实权项I |
| PC-04/05 | 每特征有行；未找到存实际范围；摘要代权项/多篇拼接/模型百分数拒绝 | C；真实原件与专业评价I/B独立 |
| PC-06/07 | 外观缺能力拒；A成功B故障仍保A；重试B；取消/旧token/重放/提交前撤权 | C和真实Worker/DM8 I |
| §9纠正 | F2只使依赖行失效；F1沿用有父版；新机器不覆盖人工；旧报告复核409 | C及正式持久化/恢复I |
| PC-08 | 特征完整性、证据准确性、意见合理性分别评估，记录专家差异与样本依据 | 专家金标/允许差异未具备不称B |
| 事务恢复 | 提交缺表整笔回滚；全部行/回执/围栏/文件与双库水位一致，恢复后正反请求 | C、真实DM8/联合恢复I分别取证 |

## 9. 两遍反演与D结论

第一遍按原需求§1→9/PC-01→09正向检查：目的、原件、特征确认、每候选矩阵、分数缺口、外观隔离、部分失败、版本冲突、质量评价及全过程权限均在§2～8落位。未把未标定评分或专家指标写成已完成。

第二遍从失败/历史/权限逆向反演：最初“递归展开引用链”若合并择一分支会新增错误权项，§3改为分支保存；自然语言用户修订若冒专利原文会造证据，§2分离用户原文；来源无MODEL_INPUT却调用AI会越用途，§5单独检查；Task版改动若保旧输入/围栏会重放，§6复用跨轮及锁定；F2修订若拷贝F1成新机器会造执行事实，§7显式父行沿用；人工报告被重生覆盖或自动复核新稿均禁止。以上修正均已进入合同，不靠未来提示词弥补。

结论：仅本首条文本对照产品方法/版本/证据/授权/失败设计闭合，可以据此判本D；不声称算法/接口已实施。物理迁移、来源字段用途、真实原件/模型质量、专家接受、数值评分和外观效果仍须分别实际取证；不更改IMP-CON-PRODUCT-COMPARE-01现有依赖。技术参数由开发团队确定，不作为原业务要求或普遍法律解释；未发现新的业务/法律决定被测试替身代签。

已有实际定位/版本/围栏工程证据为同项目[字段页核验](../evidence/consultation-search-20261002/field-pages-verification.md)、[目标与DM8迁移](../evidence/consultation-search-20261002/field-goal-physical-verification.md)、[字段正式提交C](../evidence/consultation-search-20261002/field-submit-verification.md)。这里只证明可复用的原件定位与事务机制，不称已经运行本对照矩阵、从属链、纠正或专业模型；§8是后续实现必须实际执行的验收用例，不冒已通过测试。D通过仅释放设计依赖，不越过未完成的来源实现或完整验证。

## 10. 既定COMPARISON用途的精确适配

2026-10-04实施细化，不重开原D或扩展目的：Registry字段用途码为COMPARISON，来源范围Grant的动作/用途固定为COMPARE/COMPARISON，与ProductAccessPolicy枚举一致。既有QUERY/SOURCE_QUERY及DISPLAY/SOURCE_DISPLAY保持原语义；没有COMPARISON字段决议或精确Grant即拒绝。准入接受此用途码不是对任何来源签发许可，不自动修改历史决议、签授权、续期或允许MODEL_INPUT。

PC-SOURCE-COMPARISON-GUARD-01先复用现时SOURCE_SCOPE关系读取守卫：Task版、Source契约/决议/epoch/rowVersion、组织、主体、范围版、Grant代数及截止全部精确匹配，独立Grant水位查询前后核验；Task主体活跃性由调用方正式ProductConsultationAccess负责，服务主体由正式Worker端口负责，不能单独把此守卫当认证或执行入口。保持原DISPLAY调用兼容，新增包内requireComparison固定映射，不接受客户端自选用途。正式维护签发及API接线是后续同任务切片，未完成前不称产品可操作对照。机械H2/水位故障C只验证查询约束，不冒真实人员/来源用途批准、DM8 I或业务验收。

## 11. 正式维护精确签发适配

PC-SOURCE-COMPARISON-ISSUE-01复用正式`/v2/consultation/source-contracts/scopes/{sourceId}/comparison/authorize`维护路径、产品配置和证书证明；同一具名主体必须同时满足SOURCES与GRANTS，两个角色组织亦须一致。固定动作COMPARE、用途COMPARISON，不接受客户端动作/用途或附带Query/Display/Model。输入为taskId/memberSubject/taskVersion/sourceRowVersion/sourceEpoch/scopeId/scopeVersion/requiredFields/expiresAt/expectedEpoch，Idempotency-Key另传；requiredFields仅当前已实现TITLE/CLAIMS精确字段，不开放新来源字段。维护身份、组织和每个输入字段参与长度前缀SHA，稳定排序字段，不串接可歧义的自然文本。

仅已有当前Task绑定SourceScope可被此命令使用，缺Scope返回缺口，不借此自动签Query。Task、Scope、来源契约/决议/水位与逐字段COMPARISON准入均须匹配；来源产品决议仍绑定同组织/Task。Task仍IN_PROGRESS且未到期，成员为活跃产品人类身份，Task READ及精确DataScope核验沿已有签发核心，服务Worker授权不伪装成人类。所有所需字段的用途期限必须覆盖新Grant期限。当前范围Grant是整SourceScope的COMPARISON，不宣称新增字段级Grant实体；逐次读取仍逐字段核同决议用途，输入requiredFields和完整摘要入已有Grant审计，以便核查本次签发所需字段。

独立Grant水位change包住主库事务，锁Task和成员，事务内重核来源现时状态/字段与范围，复用id2_grant/current_epoch/event签发、幂等与撤权，不建平行授权台账。重放仍核活跃主体、当前Task/范围/用途、Grant状态及现时来源，不用旧回执复活权利；同请求不同字段/范围/期限拒绝。拒绝不留下半个Grant，水位写入中断按既有PENDING关闭访问。幂等重放只有一份Grant/ISSUE事件，独立水位可按既有受控change审计推进，不把代数推进伪称新增授权。持久化无需新增表或迁移；本细化正向复核固定权限映射，逆向复核跨组织、隐含Query、停用重放和字段期限，沿原D通过，仅释放该签发适配C/I，不放行原文入模或业务验收。

物理核对修正：v850实际揭示V037的ck_con4_field_use未包含COMPARISON，因此上述“无需迁移”仅指无需新Grant表，不能忽略既有用途约束。2026-10-04核当前最大V091后，在同签发切片登记V092/U092__product_source_comparison_use.sql，仅为原枚举增加COMPARISON，不改旧迁移/数据。正逆均先添加临时约束、再替换命名约束，确保DM8 DDL非事务场景不出现无约束窗口；逆迁移第一步先校验全部旧值兼容，存在COMPARISON时失败且保留扩展约束，不清理记录。列/主外键/索引/长度/状态和保留策略不变。两遍复审确认授权意义仍由逐字段决议+Grant决定，DDL支持值不等于来源准入；C实测正向接受、未知值拒绝、带新值回退拒绝、无新值往返，真实DM8物理I另待环境，未通过前不称物理验证完成。

## 12. 用户技术方案原件读取适配

PC-TARGET-ORIGINAL-01是§2目标类型的技术细化，不改变最终输入合同：用户须显式指定同Task中已保存的messageId作为技术方案原文，服务不从检索query/目标对象或模型摘要自动制造目标。内部读取适配复用ProductTaskDirectory及ProductConsultationAccess的Task READ，绑定expectedTaskVersion及con3_message.content_sha/expires_at；响应前重读原文和现时权限/Task版。现时没有授权、消息过期/不属于Task即拒绝；保留旧消息不是自动授权其参与新分析。

精确原件标识TASK_MESSAGE:{taskId}:{messageId}，版为USER_MESSAGE_SHA256:{sha}，/raw_text表示已存CLOB字段定位而不是专利JSON或虚构磁盘文件。SHA和spanSHA取该保存原文的UTF-8编码，byteStart/End为该编码的半开范围；不去空格、不规范化、不把中文/emoji字符位当字节位。拒绝非法代理对和拆半字符，字节预算沿已有goal-retention.max-bytes，不另加开发期限/预算。准备链须显式使用该目标适配，特征用户确认仍另有CAS/不可变版/审计，不由读原文动作代签。目标专利分支继续复用Source DISPLAY/COMPARISON，不由此适配开放。机械C不证明曾有真实用户确认或专业效果。
