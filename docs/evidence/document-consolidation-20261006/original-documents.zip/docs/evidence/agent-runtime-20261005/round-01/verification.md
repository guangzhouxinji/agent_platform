# 2026-10-05 本轮Agent Runtime机械内核实测证据

任务状态唯一见docs/08；本记录保存执行范围/结果，不是平行任务台账。关联ARC-AGENT-REFACTOR-01、IMP-AGENT-RUNTIME-KERNEL-01。[限定R/D](../../../adr/agent-runtime-kernel-20261005.md)。

## 代码与真实执行范围

生产源码：kernel内AgentContract、AgentPorts、AgentRuntime；无Spring/领域/DB/供应商依赖。核心库实际执行Observe/Plan/Act/Evaluate/Re-plan/Stop，每个advance一个持久状态，先预留调用后执行，恢复同一键。Definition、Task、Goal、Plan、工具白名单/Skill绑定、SHA证据引用、完成Evaluator、人工门结论、预算、StopReason及checkpoint/audit端口已交付。当前授权在执行前后和Observe/Evaluate返回后重核；跨run调用键与不可达执行位置拒绝。

测试真实读取和写入临时文件，通过JSON原子磁盘checkpoint文件重新创建Store/Runtime恢复；持久化失败注入验证原反例与同键幂等调用。DiskStore与测试Skill仅在src/test，无产品路由/开发身份/正式动作旁路；不作为生产DM8存储或领域工具替代。生产Checkpoint适配器、领域Fence/事务接线、独立三域Definition/Skills、产品API/页面尚未交付。CompletionEvaluator接口不能独自证明业务合同完整，也不能由模型意见充当已满足。

## 命令与结果

Java使用D:/software/jdk-21，Maven3.9.16。
- `mvn -f backend/pom.xml -pl kernel verify`：最终27项，0失败/错误/跳过，jar实际生成。初轮23、复核26均保留，数字演进不是累计不同场景数。
- `node --test scripts/lib/agent-boundaries.test.mjs`：2项通过；覆盖三Agent内部实现/模块依赖及kernel对领域/框架/DB/HTTP的禁止依赖。实际结构检查退出0，124软告警仍保留。
- `npm test`（frontend）：20套74项通过；jsdom getComputedStyle警告未当失败或视觉验证。
- `npm run build`（frontend）：退出0。前端源码本轮未修改，不称Agent工作台已实现。
- `mvn -f backend/pom.xml test`：退出1；kernel当时23、consultation106、enforcement105、adjudication84无失败/错误/跳过；platform-api1097/0失败/20错误/119跳过；mock-center模块未执行。结果在完整原始log，失败XML和错误清单均保留。该全量在最终kernel边界补强之前开始，最终kernel另27项验证，不将全量描述为最终全仓绿色。
- `mvn -f backend/pom.xml -DskipTests -Dplatform.api.finalName=agent-platform-agent-refactor-20261005 package`：14模块构建退出0，独立platform-api包名避免替换运行中的默认包；明确跳过测试，不当测试通过。
- `node scripts/verify-all.mjs`：前置1(TEST_EVIDENCE_STALE)；中段完整0；后置1(TESTS_FAILING)。始终47需求文件/41契约基线一致。全量报告产生20错误后后置红灯是真实结果，不清掉旧失败或换专项报告冒绿。

## 全量错误定位与安全继续范围

20错误均为既有执法实证测试缺少DM8_JDBC_URL、JOB_PACK_DM8_URL、ENF_ACCEPTANCE_BUSINESS_URL或文书negative/recovery证据输入，不是内核断言失败。已读取verify-enforcement-document-rule-final/frozen/negatives、followup-dm8和隔离回归脚本；它们依赖真实历史业务库、浏览器结果及文件SHA，不能通过随机测试库或伪造result替代。Docker清单当前只有agent-platform-dm8的5237端口在运行，未发现这些测试预期的5311/5312环境。没有为绿灯删除/排除/改跳过测试，没有停止现有服务、改运行库或复活旧来源授权。下一步仍可继续内核与限定接线设计；全量实证环境安全重建/原证据恢复由工程执行者处理，不归为等待业务模板。

没有执行本轮生产DM8、真实供应商模型、真实案件、独立部署/扩容、三域Task级Golden评测或浏览器E2E。不得从构建/组件/结构通过推导这些已验证，也不提升41项需求V/A。

源码与原始结果SHA见manifest.json；测试XML及日志均为本轮原件复制，未覆盖历史实证目录。
