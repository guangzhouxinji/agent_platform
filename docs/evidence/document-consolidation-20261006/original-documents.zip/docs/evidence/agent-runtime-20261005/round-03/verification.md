# 2026-10-05 三独立Agent增量代码与实际执行证据

任务状态唯一见 `docs/08-总开发实现计划.md`。本文件记录原件、执行范围和覆盖边界，不是平行状态台账。关联 Runtime/Model/三域接入/Identity/Workbench 任务；技术设计见 [产品接线ADR](../../../adr/agent-runtime-product-binding-20261005.md)。需求47文件/41契约基线未改，原冻结能力及第一轮证据保留。

## 实际代码

- kernel：版本化 Runtime、类型化工具错误恢复、失败游标保留、不能把失败步骤判定完成；当前SecurityException归类PERMISSION_BLOCKED。
- persistence-dm8：AES-256-GCM绑定run/agent/task/revision，加密Checkpoint与Audit同一不可变revision，CAS/回滚/现时权限回调/保留拒绝/过期清除，V096/U096。未向现存业务schema运行迁移，DM8仅随机自有schema。生产启用无默认密钥。
- model adapter：共用有界真实HTTP/全响应超时/不跳转/严格UTF-8/当前配置复核；回答、检索对话、材料整理、专利候选分析/特征提取、意图提取五类访问已迁移。裁决原供应商/模型批准限制不放宽。429等实际HTTP状态兼容原业务错误；未知usage不伪造零成本。健康探针、完整模型路由/批准/成本审计未完成。
- consultation/enforcement/adjudication分别拥有自己的Agent定义、Skill/Tool白名单、任务与Prompt/Policy/Evaluation版本、生命周期和Runtime实例。内核没有业务流程，领域之间不调用彼此内部实现。
- 三域Product API各自提供start/read/advance，独立部署入口显式装配共享Runtime。咨询保留原Worker/Fence/Source/已确认Goal；执法调用原证据/规则/程序/文书服务、不签发/处罚/复核；裁决调用原CaseWork/可选批准材料整理/持久报告服务、不提交/裁决。
- 前端共享AgentTaskPanel仅消费领域真实请求端口，展示Goal/Phase/Plan/cursor/pending/引用SHA/events/outcome。失权清除、旧任务迟到响应忽略、网络不确定保留创建键、停止禁用继续；不制造静态进度或审批。咨询/裁决可以显式启动已有目标，执法本切片只读取/推进已有Run，不猜测程序选择或补假输入。

## 已实际运行的专项

| 执行 | 实际结果 | 边界 |
|---|---|---|
| Runtime内核 | 30项0失败/错误/跳过 | 真实文件及磁盘恢复；新增可恢复失败EVALUATE→REPLAN、游标/权限/预算 |
| Checkpoint H2 | 10项0失败/错误/跳过 | 真SQL/事务/并发/加密/回滚/恢复/迁移逆向 |
| Checkpoint真实DM8 | 10项0失败/错误/跳过 | 每例随机自有schema，复用现存实例但不改业务schema；创建后清除 |
| 裁决Task HTTPS/H2 | 5项0失败/错误/跳过 | 真嵌入式HTTPS、签名JWT/session/current Grant、独立来源授权库、SQL报告，不是Controller mock |
| 同组裁决Task/两独立DM8 | 5项0失败/错误/跳过 | 主实例随机schema + 新自有授权实例随机schema，真实HTTP与领域持久化 |
| 前端 | 21套79项通过，生产构建退出0 | 含共享面板5反例，组件验证不是浏览器E2E |
| 结构/边界 | 结构退出0，125软告警保留；2护栏通过 | 不能证明专业正确性或可独立扩容 |
| 历史DM8环境恢复 | 模板、法律参考、Followup迁移3项通过 | 自主注入现存管理员凭证，仅测试自己随机schema；不替代历史浏览器对账库 |

裁决5场景：实际工具链与重启/单报告NEED_HUMAN；匿名/无grant/只读拒绝写；材料变更后的确切inputVersion过期；报告已提交而Checkpoint事务失败503后重启同键重放、无第二报告；WRITE撤权后重启仍拒绝推进，已授权READ可看保留历史。

这组任务输入来自既有明确工程替代材料包，只是工程链路验证，不冒现实案件或法律事实。专利状态为缺口 `OFFICIAL_STATUS_NOT_VERIFIED`，不得当权威状态已分析；争点/法律/要素目前主要读取已记录候选与人工对应，专业分析仍未完成。咨询与执法正式接线已编码、编译和受影响回归，但自身完整Task级真实运行尚未取证，不能由裁决用例推导已完成。

## 初始全量与治理真实红灯（历史原件保留）

`mvn -f backend/pom.xml test` 本轮初始执行退出1：platform-api **1122项，0断言失败，20错误，119跳过**。错误仍是原执法真实环境/历史浏览器negative/dependency/recovery输入缺失。kernel/consultation/enforcement/adjudication模块无失败错误；mock-center后继未运行。保留完整原日志及默认失败XML，不排除、不删除、不改跳过，不以新专项XML覆盖旧失败。

原全量20错误中三项独立随机schema DM8能力已经再次实际通过，但原全量结果仍20错误，不能改成“全仓绿”或“只剩17”而没有重新全量实证。历史执法对账必须恢复原对应备份、原件、授权水位及browser结果；随机空schema不可以冒替。

`verify-all`前置与阶段后置当前均保留 `TESTS_FAILING:project`，此前其他失败尝试亦保存。治理47/41一致。verify-all在项目健康红灯处停止，结构检查和三Agent依赖护栏另行实际运行通过，不说整个脚本通过。

## 失败原件与修复

- 第二轮Checkpoint首次迁移路径错误，修正为Surefire工作根 `db/dm8/...` 后通过。
- 第二轮裁决Iterator误用修正为`forEachRemaining`，保留初始编译失败日志。
- 网关HttpClient内部HttpTimeoutException与外层TimeoutException竞态曾误归类UPSTREAM_UNAVAILABLE，现逐层分类TIMEOUT，测试通过。
- 迁移专利候选模型路径首次429兼容断言失败，网关Failure保留实际upstreamStatus后恢复原业务状态语义，测试通过。
- 裁决Task首次断言误读CaseWorkView字段`workVersion/report`，按真实`version/reports`修正；没有削弱真实报告/回执断言。
- 新自有DM8启动脚本首次等候错误日志谓词超时，未运行测试；核实际`DM Database is OK`及5321 TCP后复用该自有实例，两DM8任务测试通过。诊断JSON保存，不宣称第一次启动核验成功。
- 前端首次构建误用不存在的Goal.goalId，按既有合同inputId绑定；修正后79项与构建通过。

## 复验与未覆盖

复验脚本 `scripts/verify-agent-runtime.ps1`，可选`-Dm8`要求明确注入数据库参数，不猜测凭据或自动迁移业务库；每次独立证据目录，前后全量治理红灯不吞掉。脚本实跑原件第一次证据收集错误原件保存于 `../round-03-script-check/`；修复后完整实跑结果见 `../round-03-script-fix-check/result.json`。

## 环境恢复追加实证

进一步扫描全部（含停止）Docker容器后发现原5311/5312两个实例及原卷仍在。本轮核用途标签/容器ID/端口/挂载，实际重启原实例，没有空库替换、重发Grant或重新制造来源/浏览器结果。使用原加密凭证与ENF13-FINAL-20261001-101记录的原始引用，14项历史冻结反例/依赖/attempt/恢复只读对账通过；原实例保留运行。`scripts/verify-agent-historical-enforcement.ps1`已实际执行，原件在`../round-03-history-script/`，包含输入文件SHA。

首个历史attempt错误用了早于attempt表的45轮包（0记录）；按冻结101脚本反查修正为57轮原包，没有修改测试或DB。第二次新shell遗漏FINAL_CATALOG环境参数，原错误保留；可复验脚本汇总所有原参数，14项全部0失败错误跳过。这证明工程环境可自主恢复，不宣称新物理备份恢复或真人验收。恢复后全量执行原件另存，不覆盖初始20错误。

主DM8随机Checkpoint schema均在测试后清除；临时5321授权实例/自有卷在全部两DM8验证与脚本复验完成后已核标签/ID并清理，原5237实例和原5311/5312数据卷没有移除。

新复验脚本第一次误用点分隔报告后缀导致reports=[]，实际测试/构建成功但证据收集错误，不当脚本完成。按Surefire真实连字符后缀修复，新增missingReports失败条件；新证据目录重跑11套120项（0失败错误跳过）及前端79/构建通过，前后verify-all仍红，详`../round-03-script-fix-check/result.json`。原错误目录不覆写。

尚未验证/完成：咨询与执法完整Task真实链及领域重规划、三Agent独立Golden质量评测/八指标、完整专业Skill、三域工作台浏览器E2E/完整运行列表/执法启动选择、V0全域收口、Checkpoint生产清理调度/密钥轮换、完整受管模型路由/成本/可用性审计、独立发布扩容/生产启用与真人采用。没有调用付费供应商做本轮专业验收，没有修改正式决定或推倒原业务能力。

原始日志与XML见本目录及script-check；源码/证据SHA在manifest.json。报告必须区别组件、受控模型HTTP、真实DM8工程链和专业/真人验收。


## 固定Clock新增回归修复与完整构建

恢复环境第二次全量为1128项/0断言失败/46错误/40跳过，完整日志保存，不覆盖首轮1122/20/119。42错误来自固定Clock夹具和共用admit壁钟混用，过21:00北京时间导致CK_CON4_SOURCE_VALIDITY拒绝。通过新任务VER-AGENT-CLOCK-REGRESSION-02，仅增加测试工具Clock重载并在固定Clock准备夹具传同一Clock，生产来源期限、DB约束、真实授权与冻结业务代码均未改。受影响42项及工具自身3项合计45项0失败错误跳过；旧源码在pre-clock-repair。新修复不冒专业验收。

14模块最新package退出0，包名agent-platform-agent-refactor-round03，避免覆盖默认运行jar；明确-DskipTests，构建证据不当测试通过。此前前后verify-all仍TESTS_FAILING；后继隔离全量各次原件与最终结果见下节，不以专项或构建冒全仓绿。

既有全量Suite有DM8_JDBC_URL即激活的历史V0测试，会在给定账号中做旧迁移/逆向；第二轮使用5237的SYSDBA执行了该历史测试范围（不是ADMIN业务schema），不能宣称第二轮全部只在随机schema运行。最终重跑已为此类测试新建独立5323实例/自有卷，避免后续再使用现存实例的管理schema。保留实际范围，不更改这些既有测试或让它们跳过。


## 隔离全量初次结果与启动前置修复（续轮）

固定Clock修复后的隔离5323全量于2026-10-05T21:26:26+08:00结束，platform-api **1116项/0断言失败/10错误/40跳过**，退出1。318份默认XML完整另存`full-isolated-initial-reports/`，日志`full-isolated-initial.log`，计数`full-isolated-initial-result.json`。不能替换或抹去原1122/20/119及1128/46/40。

其中7错误是隔离库启动前缺KB_RECORD_VERSION，Spring在既有@BeforeAll迁移前构造知识库适配器，导致上下文失败；因此生命周期整套测试只记初始化错误，1116不与1128等同为测试删减。其余3是JobPack/RealBusinessCollection未注入专用隔离夹具，以及授权fixture未提供可安全写入的独立authority参数。没有向原业务/授权库运行这个授权fixture。

临时Java准备工具仅接受5323精确地址、先检查表、调用既有LocalKnowledgeBaseImporter：首次保守检查发现既有表即退出；第二次类路径缺公开resource退出；补齐原platform-api资源后返回ImportResult三类均0，确认已有公开导入记录，不制造新业务数据。三个尝试日志与实际命令源均保留；没有改生产代码/初始化规则或削弱测试。准备后不筛选测试的全量复跑原件为`full-isolated-kb-ready.log`，执行结束前不标为通过。

最终前端再次实际21套79项通过，生产构建0，日志`frontend-final-tests.log`/`frontend-final-build.log`和exit.json；jsdom的getComputedStyle pseudo-elements提示仍保留，组件通过不是浏览器验证。治理/自测/架构边界均0，结构125软告警仍保留。源码69份SHA逐项核对无漂移。


## 本轮最终全量、剩余前置与资源清理

未筛选的`mvn -f backend/pom.xml test`于 **2026-10-05T21:40:39+08:00**结束，platform-api **1128项、0断言失败、4错误、40跳过**，退出1；后继mock-center-api未执行。318份默认XML保存在`full-isolated-final-reports/`，逐套与总数在`full-isolated-final-result.json`；实际命令`isolated-full-command.ps1.txt`、日志`full-isolated-kb-ready.log`、退出记录`full-isolated-kb-ready-exit.json`。知识库前置恢复后原7个启动错误不再出现，42个固定Clock错误也未再现。结果中40条件跳过保留，不算验证完成。

4个错误逐项：
- JobPackDm8IntegrationTest：缺JOB_PACK_DM8_URL/USER/PASSWORD。
- RealBusinessCollectionDm8Test：同名参数还要求专有新实例/卷、随机空schema和原件目录归属检查，不能给历史库或本轮Runtime隔离库冒替。
- EnforcementFollowupAcceptanceGrantFixtureTest：未提供ENF_ACCEPTANCE_AUTHORITY_SCHEMA等专用可写授权准备参数；本轮有意不向原冻结授权库签发或续期Grant。
- EnforcementDocumentRuleFacilityFixtureTest：本续轮命令误传ENF_DOCUMENT_RULE_ATTEMPT_MIGRATION，真实测试要求ENF_DOCUMENT_RULE_MIGRATION_FILE。保留本轮命令错误，不归咎业务或吞掉测试。

最后一项已自主改正确参数，先真实只读查询原5311两张attempt表均已存在，才专项执行fixture：**1项0失败错误跳过**，没有运行迁移/更改业务行。证据`facility-readonly-precheck.log`、`facility-correct-env.log`及`TEST-...-AGENT_R3_FACILITY_ENV_FIX.xml`。这是对应错误的专项修复，不等于新一轮全量，所以全量仍记4错误，不能改成3。其余夹具待工程隔离供给，不是业务模板等待，不阻咨询/执法任务链继续实施。

测试结束后再次核5323容器/卷精确名称、role/run-id标签、唯一卷使用者、挂载和端口；保存脱敏容器日志与metadata，实际删除仅本轮自有`codex-agent-full-bbd9821d27aa`及其卷。`full-owned-before-cleanup.json`与`full-owned-cleanup.json`记录容器ID、标签、退出及原5237/5311/5312实例/卷仍保留运行。5321清理原证据不覆盖。V096只在测试自有schema使用，未迁移现存业务schema；旧第二次全量使用5237 SYSDBA执行历史迁移测试范围仍如实披露。

总体仍IN_PROGRESS / PARTIAL。源码69份及本轮原件SHA见source-manifest.json与manifest.json，索引不取代主计划状态台账；专项重跑有重叠，不将各次执行数相加当独立业务验收数量。


最终主计划V9.599后置`verify-all.mjs`实际退出1，仅`TESTS_FAILING:project`；47基线/41契约一致、生成692项任务的JSON/dashboard，不篡改旧全量报告来消除红灯。直接governance及其self-test/Agent边界退出0，结构125软告警保留。红灯原件`verify-final-after-close.log`，独立治理`governance-final-after-close.log`；不是声明verify-all所有后继脚本均已运行。
